# LAUNCH CHECKLIST: FOCUS FIRST DIGITAL LAB
## 6-Week Launch Timeline

**Timeline:** 6 weeks (start: July 23 → end: early September 2026)  
**Platform:** Next.js + Vercel  
**Design:** Self in Figma  
**Goal:** Website live + cold outreach started

---

## WEEK 1: BRAND FOUNDATION (July 23-29)

### Logo & Brand Assets
- [ ] **Open Figma file** (Focus First Digital Lab project)
- [ ] **Design mark** (3 overlapping lines)
  - [ ] Line 1: (60, 200) → (140, 40)
  - [ ] Line 2: (128, 220) → (128, 20)
  - [ ] Line 3: (196, 200) → (116, 40)
  - [ ] Stroke: 2px, round caps/joins
  - [ ] Color: Dark Gray `#3A3935`
- [ ] **Create 4 variants:** Outline (dark), filled (emerald), inverted (white), solid
- [ ] **Design wordmark:** "FOCUS FIRST" (Inter Bold 48px) + "Digital Lab" (Inter Regular 20px)
- [ ] **Create 4 lockups:** Horizontal, stacked, mark-only, wordmark-only
- [ ] **Export SVGs:** mark-dark.svg, mark-emerald.svg, wordmark.svg, lockup-horizontal.svg
- [ ] **Export PNGs:** favicon (32px, 64px), social-avatar (128px)

### Branding Documentation
- [ ] **Create color swatches** in Figma (all hex codes)
- [ ] **Create typography sheet** (Inter, IBM Plex Mono samples)
- [ ] **Export brand guidelines PDF** (or keep as Figma page)

### Time Estimate: 12-15 hours

---

## WEEK 2: WEBSITE SETUP & CASE STUDIES (July 30-Aug 5)

### Website Foundation
- [ ] **Create Next.js project** (`npx create-next-app@latest focusfirst`)
- [ ] **Install dependencies:** Tailwind CSS, MDX (for blog)
- [ ] **Set up folder structure:**
  ```
  /app
    /layout.tsx
    /page.tsx (homepage)
    /cases
      /treepin/page.tsx
      /tagalong/page.tsx
      /iot/page.tsx
    /process/page.tsx
    /pricing/page.tsx
    /contact/page.tsx
  /components
    /Header.tsx
    /Footer.tsx
    /CaseStudyTemplate.tsx
  /public
    /logo-*.svg
    /favicon.ico
  ```
- [ ] **Add brand colors to Tailwind config**
  ```js
  colors: {
    white: '#FFFFFF',
    cream: '#F9F8F6',
    'light-gray': '#F0EEE8',
    'medium-gray': '#A9A8A1',
    'dark-gray': '#3A3935',
    'near-black': '#1A1915',
    accent: '#2DB88F',
    'accent-dark': '#1B6E4F',
  }
  ```
- [ ] **Add typography to Tailwind** (Inter, IBM Plex Mono via Google Fonts)
- [ ] **Set up favicon** (32px PNG)

### Case Studies Written
- [ ] **Treepin case study** (800-1000 words)
  - Problem, Data, Solution, Outcome, Learnings
  - Include: timeline, tech stack, metrics
- [ ] **Tagalong case study** (800-1000 words)
  - Problem, Data, Solution, Outcome, Learnings
  - Include: timeline, tech stack, metrics
- [ ] **IoT case study** (500-800 words, can be shorter)
  - Problem, Data, Solution, Outcome (or projected)
- [ ] **Copy all case study text to markdown files** (for MDX)

### Email Setup
- [ ] **Create email signature template** (HTML, with logo, contact info)
- [ ] **Verify email forwarding** (jonathan@focusfirst.studio or .be?)

### Time Estimate: 15-20 hours

---

## WEEK 3: HOMEPAGE & CORE PAGES (Aug 6-12)

### Homepage (page.tsx)
- [ ] **Hero section**
  - Logo + tagline
  - "Focus First Digital Lab"
  - "We analyze your problem. Build the solution. Fast."
  - CTA button: "Let's talk" → Calendly link
  - Background: minimal geometric shape (light gray circle)
- [ ] **Process section**
  - 3 columns: Analyze (icon: magnifying glass)
  - Build (icon: database)
  - Ship (icon: rocket)
  - Each with description + week timeline
- [ ] **Case studies section**
  - 3 cards: Treepin, Tagalong, IoT
  - Problem + Outcome visible
  - Link to full case study
- [ ] **Who uses this section**
  - 4 boxes: Municipalities, Construction, Startups, Nonprofits
  - Icon + description for each
- [ ] **Pricing section**
  - 3 tiers: Quick Win (€3-5k), MVP (€8-12k), Smart App (€15-25k)
  - What's included/excluded
  - CTA: "Let's scope your project"
- [ ] **About section**
  - Photo or avatar (simple, not stock)
  - Bio (50-100 words)
  - Contact links

### Case Studies Pages (cases/[slug]/page.tsx)
- [ ] **Treepin case study page**
  - Full content (1200+ words)
  - Problem section, Data section, Solution, Outcome, Learnings
  - Optional: timeline diagram, tech stack badge
- [ ] **Tagalong case study page**
  - Full content (1200+ words)
  - Same structure as Treepin
- [ ] **IoT case study page** (if enough content)
  - Or: placeholder "Coming soon"

### Process Page (process/page.tsx)
- [ ] **Detailed process breakdown**
  - Week 1-2: Analyze (headings, bullet points)
  - Week 3-5: Build (headings, bullet points)
  - Week 6-8: Ship (headings, bullet points)
  - Why this timeline? (paragraph)
  - What doesn't work (list of scope creep examples)

### Styling
- [ ] **Navigation bar** (logo + nav links)
- [ ] **Footer** (copyright, email, social links)
- [ ] **Responsive design** (mobile first)
- [ ] **Tailwind utility classes** (no custom CSS if possible)

### Time Estimate: 20-25 hours

---

## WEEK 4: PRICING, CONTACT, POLISH (Aug 13-19)

### Pricing Page (pricing/page.tsx)
- [ ] **Pricing tiers** (copy from communication plan)
- [ ] **Comparison table** (what's included/excluded)
- [ ] **FAQ section** (5-7 common questions)
- [ ] **CTA:** "Let's talk"

### Contact/About Page (contact/page.tsx)
- [ ] **Simple contact form** (Name, Email, Message)
  - Optional: Supabase integration (if you want to capture leads)
  - Fallback: Just link to email + Calendly
- [ ] **Calendar embed** (Calendly iframe)
  - "Schedule a 30-min call"
- [ ] **Social links** (LinkedIn, GitHub, Email)
- [ ] **About section** (bio, background)

### Blog Setup (blog/page.tsx + blog/[slug]/page.tsx)
- [ ] **Blog index page** (list of posts)
- [ ] **Blog post template** (MDX layout)
- [ ] **First blog post drafted** ("Why 90% of digital projects fail")
  - Save as draft (publish Week 5)

### Technical Polish
- [ ] **Lighthouse audit** (performance, accessibility, SEO)
  - Target: >90 score
- [ ] **Mobile responsive check** (phone, tablet, desktop)
- [ ] **Link verification** (all internal links work)
- [ ] **Image optimization** (next/image for automatic sizing)
- [ ] **Meta tags** (og:image, og:description for social sharing)
- [ ] **Analytics setup** (Google Analytics 4 tracking)
- [ ] **Vercel deployment setup** (git integration, auto-deploy)

### Time Estimate: 15-18 hours

---

## WEEK 5: LAUNCH WEBSITE + START OUTREACH (Aug 20-26)

### Deployment
- [ ] **Vercel project setup**
  - Connect GitHub repo
  - Set environment variables (if needed)
  - Enable auto-deploy on git push
- [ ] **Domain setup**
  - [ ] Buy focusfirst.studio (via name.com or Vercel)
  - [ ] Buy focusfirst.be (via DNS Belgium)
  - [ ] Point focusfirst.studio to Vercel
  - [ ] Set up email forwarding (focusfirst@[domain] → your email)
- [ ] **SSL/TLS** (Vercel handles automatically)
- [ ] **Site launch checklist**
  - [ ] Homepage loads
  - [ ] Case studies load
  - [ ] Links work
  - [ ] Forms work
  - [ ] Images load fast
  - [ ] Mobile responsive
  - [ ] Calendly embed works

### LinkedIn Profile Update
- [ ] **Update profile image** (new avatar, professional)
- [ ] **Update header image** (focusfirst branding, 1200×628px)
- [ ] **Update headline:** "Building digital prototypes. Problem → Data → Solution. 6-8 weeks."
- [ ] **Update about section** (link to website)
- [ ] **Create company page** (Focus First Digital Lab)
  - Add logo
  - Add description
  - Add website link
- [ ] **Schedule first 8 LinkedIn posts** (Week 5-6)
  - Post 1: "Why 90% of digital projects fail"
  - Post 2: "We built Treepin for gemeente Maldegem"
  - Post 3: "The 6-8 week framework"
  - Post 4: "What we don't build (and why)"
  - Post 5-8: Mix of case studies + methodology posts

### Cold Outreach Prep
- [ ] **Email templates finalized**
  - Template 1: Municipalities (digitalization officers)
  - Template 2: Construction firms (project managers)
  - Template 3: Startups (founders)
- [ ] **Target list compiled**
  - 20-30 municipalities (Flanders)
  - 15-20 construction firms
  - 10-15 startup/scale-ups
- [ ] **Personalization notes** (for each template)
  - Research recipient's pain point
  - Add specific detail (e.g., "I noticed your municipality manages 50k+ trees")

### Time Estimate: 12-15 hours

---

## WEEK 6: OUTREACH + CONTENT (Aug 27-Sep 2)

### Cold Outreach Launch
- [ ] **Email outreach begins**
  - [ ] Send 20-30 emails to municipalities (personalized)
  - [ ] Send 15-20 emails to construction firms
  - [ ] Send 10-15 emails to startups
  - Use: Subject line, brief copy, CTA to calendar
- [ ] **LinkedIn engagement**
  - [ ] Post 1 goes live (Monday)
  - [ ] Engage with comments (reply within 24h)
  - [ ] Post 2 goes live (Thursday)
  - [ ] Repost 1-2 valuable insights from network

### Content Calendar Execution
- [ ] **Blog post 1 published** ("Why 90% of digital projects fail")
- [ ] **Blog post 2 drafted** ("The data flow audit")
- [ ] **LinkedIn posts 3-8 scheduled** (for weeks 6-8)

### Pipeline Management
- [ ] **Spreadsheet created** (tracking cold outreach)
  - Column: Contact name, email, date sent, response, next steps
- [ ] **Calendly link shared** in all emails
- [ ] **First conversations starting** (follow-ups from Week 5 emails)
- [ ] **First proposals drafted** (if leads come in)

### Time Estimate: 8-10 hours

---

## WEEK 7-8: MOMENTUM + ITERATION

### Ongoing Activities
- [ ] **LinkedIn:** 2 posts/week (Monday + Thursday)
- [ ] **Blog:** 1 post per week
- [ ] **Cold outreach:** Follow-ups to Week 5-6 non-responders
- [ ] **Sales:** First conversations converting to proposals
- [ ] **Website:** Updates based on early feedback

### Metrics Tracking
- [ ] **Website analytics** (Google Analytics)
  - Traffic volume
  - Most visited pages
  - CTA click-through rates
- [ ] **LinkedIn metrics**
  - Post engagement (likes, comments, shares)
  - Profile views
  - Connection requests
- [ ] **Sales metrics**
  - Cold emails sent
  - Response rate
  - Conversations scheduled
  - Proposals sent
  - Deals closed

### Website Iteration
- [ ] **A/B test homepage CTA** (if traffic allows)
- [ ] **Add testimonial section** (if first client willing)
- [ ] **Update case studies** (with outcomes from first projects)

---

## FINAL CHECKLIST (Before Launch)

### Technical
- [ ] Website on Vercel (deployed)
- [ ] Domain pointing to Vercel (DNS configured)
- [ ] Email forwarding working (test email sent)
- [ ] Favicon visible (browser tab shows logo)
- [ ] Mobile responsive (tested on phone)
- [ ] Analytics tracking (GA4 events firing)
- [ ] Calendly embed working (can book call)
- [ ] Forms working (if email capture used)

### Content
- [ ] Homepage live (all sections)
- [ ] Case studies live (3 minimum)
- [ ] Pricing page live
- [ ] Contact/About page live
- [ ] LinkedIn profile updated (with link to website)
- [ ] Email signature updated (with logo, link to website)

### Marketing
- [ ] 8 LinkedIn posts scheduled (Week 5-6)
- [ ] 20-30 cold emails ready to send
- [ ] Email templates personalized
- [ ] Calendly link in all emails/posts
- [ ] Blog post 1 published
- [ ] Outreach spreadsheet created (tracking)

### Branding
- [ ] Logo finalized (SVG + PNG exports)
- [ ] Colors locked in (hex codes in Tailwind)
- [ ] Typography consistent (Inter + IBM Plex Mono)
- [ ] Favicon set
- [ ] Social media assets created (profile pic, header)

---

## TIME SUMMARY

| Week | Task | Hours | Cumulative |
|------|------|-------|-----------|
| 1 | Brand foundation (logo, assets) | 15 | 15 |
| 2 | Website setup + case studies | 18 | 33 |
| 3 | Homepage + core pages | 22 | 55 |
| 4 | Pricing, contact, polish | 16 | 71 |
| 5 | Deploy + LinkedIn + prep outreach | 13 | 84 |
| 6 | Launch outreach + content | 9 | 93 |
| **Total** | | **~93 hours** | |

**Breakdown:**
- Figma/Design: ~25 hours
- Development (Next.js): ~45 hours
- Content (copy, blog): ~15 hours
- Deployment/setup: ~8 hours

**Pace:** ~15 hours/week (sustainable, ~3-4 hours/day)

---

## SUCCESS CRITERIA (End of Week 6)

✅ **Technical:**
- Website live on focusfirst.studio
- All pages load quickly (>90 Lighthouse score)
- Mobile responsive
- Analytics tracking

✅ **Content:**
- Homepage complete with all sections
- 3+ case studies live
- Blog post 1 published
- Pricing + Contact pages live

✅ **Marketing:**
- 50+ cold emails sent
- LinkedIn profile updated, 2+ posts live
- First 5-10 conversations started
- First 1-2 proposals drafted

✅ **Branding:**
- Logo finalized and approved
- All brand assets (logo, colors, fonts) implemented
- Consistent across website + social media

---

**Document Version:** 1.0  
**Last Updated:** July 23, 2026  
**Status:** Ready for execution
