# BUSINESS PLAN: FOCUS FIRST DIGITAL LAB
## Problem → Data → Solution. 6-8 weeks.

**Status:** In development (July 2026)  
**Founder:** Jonathan (Studio Huis, BE 0881.296.468)  
**Location:** Gent, Belgium  
**Structure:** Eenmanszaak (initially)  
**Domains:** focusfirst.studio | focusfirst.be

---

## PART 1: EXECUTIVE SUMMARY

### The Premise
You've built three separate products in parallel over 2-3 years:
- **Treepin**: GIS + tablet + backend + mobile app (municipality use case)
- **Tagalong**: SketchUp plugin + web backoffice (architecture/designer use case)
- **IoT water meters**: Hardware concept + cloud platform (construction/events use case)

**Pattern identified:** You are exceptionally skilled at translating concepts → working prototypes in 4-8 weeks. This is a rare, profitable skill. Standard consultancies take 4-6 months and cost 2-3x more.

### Proposition
Create a **studio focused solely on digital prototyping**: fast proof-of-concepts that validate ideas before major investment. Target: municipalities, construction firms, startups, nonprofits with €8-25k budgets.

### Market Fit
- **Municipalities** (Flanders/Wallonia): digitalization budgets +18%/year, 5000+ IT tenders/year
- **Construction sector**: software adoption accelerating, 62% cloud adoption (UK 2020)
- **Startups/SMEs**: need rapid validation without hiring full dev team
- **Gap**: Expensive consultancies ($50k+) vs. your model (€8-25k per MVP)

### Revenue Model
**Project-based pricing** (not hourly):
- Quick Win (API, small script): €3-5k
- MVP (full stack prototype): €8-12k
- Smart App (mobile + backend + integration): €15-25k

**Year 1 realistic forecast:**
- Q1: 1 project → €10-12k
- Q2-Q4: 2-3 projects/quarter
- **Total Year 1 gross revenue: €40-60k**
- **Net (after costs): ~€30-45k** (eenmanszaak, low overhead)

**Unit economics:**
- Project cost (your time): €2-4k (4-8 weeks work)
- Margin: 60-75%
- Runway: Sustainable from Q1 onward

---

## PART 2: MARKET RESEARCH

### 2.1 MARKET SIZE & SEGMENTS

#### Segment 1: Belgian Municipalities
**Market size:**
- 580 municipalities in Belgium (Flanders: ~300, Wallonia: ~200, Brussels: 19)
- Public IT budget growth: +18%/year
- Total annual IT tenders in Belgium: 5000+
- **Estimate: 100-150 municipalities actively digitizing annually**

**Budget availability:**
- Small municipality (< 20k residents): €5-10k/year for POCs
- Medium municipality (20-50k residents): €15-30k/year for app pilots
- Large municipality (>50k residents): €50k+ for strategic pilots

**Pain points:**
- Paper-based processes (permits, inspections, asset management)
- Legacy systems (expensive to upgrade, hard to integrate)
- Staff shortages (no in-house dev capacity)
- Regulatory pressure (GDPR, transparency, sustainability reporting)

**Proof:** Gemeente Maldegem demo (first real client) validates demand.

---

#### Segment 2: Construction & Vastgoed
**Market size:**
- Belgium construction sector: €50B+ annual spend
- 15,000+ construction firms operating
- **Estimate: 500-1000 firms actively seeking digital tools**

**Current software landscape:**
- Legacy: ERP tools (Astena, Plenion, Bouwflow)
- Gap: Specialized tools for **specific workflows** (site tracking, safety checklists, crew coordination)
- Budget constraint: Small-medium builders resist €5-20k SaaS subscriptions

**Pain points:**
- Site coordination (crew schedules, material tracking, safety)
- Safety documentation (photo/video logging, incident tracking)
- Real-time progress reporting to clients
- Budget overruns due to poor data visibility

**Opportunity:** POCs cost €8-15k (vs. €50k+ for custom enterprise software). Builders test before committing.

---

#### Segment 3: Startups & Scale-ups
**Market size:**
- 2000+ active tech startups in Benelux
- **Estimate: 200-400 need rapid MVP validation annually**

**Budget:**
- Pre-seed/seed stage: €5-15k for MVP (before Series A)
- Strategic pilots for larger companies: €20-30k

**Pain points:**
- Cannot afford full dev teams upfront
- Need fast iteration & user feedback loops
- Investor pressure to launch quickly
- Need "investor-ready" prototype, not perfect product

**Opportunity:** Your speed (6-8 weeks) vs. standard agency (4-6 months) is a massive win.

---

#### Segment 4: NGOs & Nonprofits
**Market size:**
- 7000+ registered nonprofits in Belgium with significant budgets
- **Estimate: 100-200 seeking digital solutions for operations**

**Budget:**
- Typically €3-8k (smaller budgets than corporates)
- Access to subsidies (digitalization grants) can supplement

**Pain points:**
- Limited IT budgets
- Operational inefficiency (volunteer coordination, donation tracking)
- Desire to scale impact without scaling overhead

---

### 2.2 COMPETITIVE LANDSCAPE

#### Direct Competitors (Prototyping Studios)
**SpeedMVPs** (Belgium/Brussels)
- Positioning: AI-first MVP development
- Timeline: 2-3 weeks (faster than you)
- Price: Not transparent; likely €15-30k+ (higher)
- Strength: Specialized in AI/ML workflows
- Weakness: Premium positioning, not cost-accessible for SMEs

**iterates** (Brussels)
- Positioning: MVP + POC + fundraising support
- Timeline: Unclear (likely 4-8 weeks)
- Price: Custom quotes
- Strength: Offers subsidy application support
- Weakness: Generalist, no domain expertise

**Belighted** (Wallonia, ~10 people)
- Positioning: Established agency (15+ years), quality-focused
- Timeline: 8-12 weeks typical for MVPs
- Price: Not transparent; likely €30-50k+
- Strength: Mature, trusted by corporates
- Weakness: Expensive, slow, overhead-heavy (10 people)

#### Indirect Competitors (Consultancy)
**Big Management Consultancy** (Deloitte, EY, etc.)
- Day rate: €1000-2000+ per person
- Project cost for 8-week MVP: €50-100k+
- Strength: Credibility, process rigor
- Weakness: Overkill for POCs, slow, risk-averse

**Freelance Developers** (Bolero, Malt, etc.)
- Day rate: €600-1200 (senior)
- Project cost for 8-week MVP: €15-30k (if coordinated well)
- Strength: Cheap, flexible
- Weakness: No accountability, fragmented team, integration risk

#### Key Insight
**You occupy a sweet spot:**
- Faster than traditional consultancy (6-8 weeks vs. 4-6 months)
- Cheaper than agencies (€8-25k vs. €30-100k)
- Single point of accountability (you deliver, no team fragmentation)
- Domain expertise (tree management, GIS, SketchUp, IoT, architecture)

---

### 2.3 PRICING BENCHMARKS

#### Freelance Day Rates in Belgium (2026)
| Role | Day Rate | Hourly (7h day) |
|------|----------|---|
| Business Analyst | €500-750 | €71-107 |
| Project Manager | €500-650 | €71-93 |
| Mid-level Developer | €650-850 | €93-121 |
| Senior Developer/Architect | €800-1200 | €114-171 |
| IT Consultant | €93,576/year avg ≈ €400/day | ~€57 |

**Implication:** Your €8-25k pricing for 6-8 week projects = €1000-3125/day effective rate, which is *premium for a solo operator* but justified by:
- Full-stack capability (design, backend, frontend, mobile, DevOps)
- Domain expertise (not generic code monkey)
- Accountability (you own delivery)
- Speed (saves client time)

---

#### Competitor Pricing (Estimated)
| Studio | Project Scope | Est. Cost | Typical Timeline |
|--------|---|---|---|
| **You** | Full MVP (6-8 weeks) | €8-25k | 6-8 weeks |
| **SpeedMVPs** | AI MVP | €20-35k | 2-3 weeks |
| **iterates** | MVP + support | €15-30k | 6-12 weeks |
| **Belighted** | MVP development | €30-50k | 8-12 weeks |
| **Freelance consortium** | Coordinated MVP | €15-30k | 10-16 weeks (fragmented) |
| **Big consultancy** | Strategic prototype | €50-150k | 12-24 weeks |

**Your positioning:** Mid-market price, fastest timeline (except SpeedMVPs), personal accountability.

---

### 2.4 DEMAND SIGNALS (Treepin as Proof)

**Gemeente Maldegem case:**
- Initial concept → MVP in ~3 months (you built this)
- Client pain: Manual tree inspections = climbing risk + high cost
- Solution: GIS + tablet + backend
- Impact: Cost savings (€50-150/inspection inspection → €10-30 digital) + safety improvement

**Market validation from this:**
- Municipalities have real budgets for software
- They move slowly (approval cycles) but commit when convinced
- Proof-of-concept is the key gating factor (not technical capability)

**Other emerging use cases you've identified:**
- Construction site tracking (IoT water meters concept)
- Design workflow automation (Tagalong plugin)
- Agricultural/environmental monitoring

---

### 2.5 MARKET TRENDS

1. **Cloud adoption accelerating**
   - EU policy push for digital government
   - SME adoption of cloud tools (62% in UK construction by 2020)
   - Implication: Your cloud-first approach (Supabase, Vercel, Mapbox) is table stakes

2. **Regulatory pressure**
   - GDPR compliance required (your RLS implementation = advantage)
   - Sustainability reporting (municipalities need data infrastructure)
   - Safety/liability documentation (construction sites)

3. **Startup/scale-up fragmentation**
   - VC funding in Europe remains strong
   - Many startups underfunded for full dev teams
   - MVP-first approach becoming standard (validate before scale)

4. **Gig economy in tech**
   - Clients increasingly comfortable with freelance/solo operators
   - Proof of prior work (Treepin, Tagalong) becomes your moat
   - Trust = reputation + case studies

---

## PART 3: BUSINESS MODEL

### 3.1 REVENUE STREAMS

**Primary: Project-based prototyping**
- Quick Win (€3-5k): 2-3 weeks
  - Small apps, API integrations, scripts, dashboards
  - Example: "Connect our municipal database to web map"
  
- MVP (€8-12k): 6 weeks
  - Full-stack prototype: frontend + backend + mobile compatibility
  - Example: "Tree inspection app for municipalities"
  
- Smart App (€15-25k): 8 weeks
  - Complex integrations, hardware/IoT, advanced features
  - Example: "Construction site IoT platform with real-time monitoring"

**Secondary (Year 2+):**
- Ongoing support/maintenance (€500-1000/month per project)
- Feature roadmap consulting (€100-150/hour, after MVP delivery)
- Training/documentation services (€50-100/hour)

**Tertiary (Long-term optionality):**
- If successful, scale via subcontractors (split revenue)
- Product extraction (if one MVP becomes repeatable template, convert to SaaS)
- Advisory (domain expertise for larger consultancy)

---

### 3.2 COST STRUCTURE

**Fixed Costs (Annual):**
| Item | Est. Cost |
|------|-----------|
| Accounting/bookkeeper | €1500 |
| Insurance (professional liability, cyber) | €800 |
| Software licenses (Figma, SketchUp, VS Code) | €200 |
| Hosting/cloud credits (personal projects) | €1200 |
| Office/workspace (home-based) | €0 |
| **Total Fixed** | **€3700/year** |

**Variable Costs per Project:**
| Item | Est. % of Revenue |
|------|---|
| Domain registrations, DNS, SSL (shared across clients) | 1-2% |
| Supabase/Vercel hosting per client | 2-3% |
| Third-party APIs (Mapbox, ElevenLabs, etc.) | 2-5% |
| **Total Variable** | **~5-10% of revenue** |

**Your time cost:**
- You value yourself at €1000-1500/day effective rate
- 6-week project = €6000-7500 internal cost
- €8-12k price = 60-100% gross margin
- 4 projects/year = €200-300 internal value, €40-60k revenue

---

### 3.3 UNIT ECONOMICS (Year 1)

**Scenario: 4 projects in Year 1**

| Project Type | Count | Avg. Price | Total Revenue |
|---|---|---|---|
| Quick Win | 1 | €4k | €4k |
| MVP | 2 | €10k | €20k |
| Smart App | 1 | €20k | €20k |
| **Total Revenue** | **4** | **€8.5k avg** | **€44k** |

**Gross Profit:**
- Revenue: €44k
- Variable costs (5-10%): €2.2-4.4k
- **Gross profit: €39.6-41.8k**

**Net Profit:**
- Gross profit: €40k
- Fixed costs: €3.7k
- Taxes (BE self-employed ~45-50% tax pressure): ~€18k
- **Net take-home: ~€18-22k** (realistic, conservative)

**Rationale:**
- Conservative (many solo consultants do 6-8 projects/year)
- Improves year 2+ with reputation, referrals, repeat clients
- Scalable via subcontractors without hiring full-time staff

---

## PART 4: MARKETING & SALES STRATEGY

### 4.1 POSITIONING PILLARS

**Core message:**
"We build digitale prototypes in 6-8 weeks. For organizations that want to test before investing €50k+. No long contracts, no bullshit, no jargon."

**Three pillars:**
1. **Speed:** 6-8 weeks vs. industry standard 4-6 months
2. **Simplicity:** Fixed pricing, clear scope, one point of contact
3. **Proof:** Portfolio (Treepin, Tagalong, Maldegem case study)

### 4.2 SALES CHANNELS

| Channel | Target | Effort | Expected ROI |
|---------|--------|--------|---|
| **Direct outreach** | Municipalities (via digitalization officers) | Medium | High |
| **LinkedIn** (thought leadership + proof) | Startups, SMEs, consultants | Low | Medium |
| **Referral** (Klaas, existing clients) | Cross-sell, word-of-mouth | Low | High |
| **Conferences** (tech/construction/municipal) | Visibility, warm introductions | Medium | Medium |
| **Content marketing** (blog, case studies) | SEO, inbound | Medium | Long-term |
| **Direct pitch** (Bolero network, Angel networks) | Startups, scale-ups | Low | Medium |

### 4.3 SALES PROCESS

**Target: Municipalities (primary)**
1. Research digitalization officer / IT coordinator
2. Cold email (personalized, reference specific pain point)
3. 30-min discovery call (understand project scope, timeline, budget)
4. Quick proposal (1 page, scope + timeline + price)
5. Decision (typically 2-4 weeks for municipal approvals)
6. Kick-off

**Timeline:** Cold outreach → contract sign = 4-8 weeks typical
**Conversion rate:** Estimate 10-15% (1 in 7-10 conversations closes)
**Implication:** Need 20-30 qualified conversations to land 2-3 projects/year

---

## PART 5: OPERATIONAL PLAN

### 5.1 DELIVERY MODEL

**Week 1-2: Discovery & Design**
- Kickoff meeting (understand requirements, constraints, timeline)
- Wireframes / mockups
- Technical architecture plan
- Approval from client

**Week 3-5: Build & Integration**
- Frontend development
- Backend development
- Database schema & API
- Integration with client systems (if applicable)
- Parallel: testing, security review

**Week 6-8: Refinement & Deployment**
- Bug fixes, polish
- User acceptance testing
- Documentation (handover guide)
- Deployment to production
- Team training (if needed)

**Post-launch:**
- 30 days of bug fix support (included)
- Optional: ongoing maintenance contract (€500-1000/month)

---

### 5.2 TOOLS & TECH STACK

**Development:**
- **Frontend:** React, TypeScript, Tailwind CSS
- **Backend:** Node.js, Express, or Python (FastAPI)
- **Database:** Supabase (PostgreSQL + RLS)
- **Hosting:** Vercel (frontend), Supabase (backend)
- **Maps:** Mapbox GL JS (GIS-heavy apps)
- **Mobile:** React Native via Capacitor (if iOS/Android required)
- **DevOps:** GitHub Actions, Vercel deploy

**Design & Planning:**
- Figma (wireframes, prototypes)
- Notion (project tracking)
- ClickUp (task management, billing-aware)

**Why this stack:** You know it well, fast iteration, low DevOps overhead, client code ownership.

---

### 5.3 QUALITY ASSURANCE

**Before delivery:**
- User acceptance testing (client validates)
- Security review (OWASP Top 10, RLS checks, API rate limiting)
- Performance testing (load testing if applicable)
- Documentation & handover (GitHub repo, deployment guide, API docs)

**Post-launch:**
- 30-day bug fix window (included in price)
- SLA: Critical bugs < 24h, Minor bugs < 5 days

---

## PART 6: FINANCIAL PROJECTIONS

### Year 1 Conservative Scenario (4 projects)
**Revenue:** €44k  
**COGS:** €3k (variable costs)  
**Gross Profit:** €41k (93% margin)  
**Operating Expenses:** €3.7k  
**EBIT:** €37.3k  
**Taxes (~45%):** €16.8k  
**Net Income:** €20.5k

### Year 2 Base Case (6 projects, referrals, reputation)
**Revenue:** €65k  
**COGS:** €5k  
**Gross Profit:** €60k (92% margin)  
**Operating Expenses:** €4.5k (slight increase for marketing)  
**EBIT:** €55.5k  
**Taxes (~45%):** €25k  
**Net Income:** €30.5k

### Year 3 Optimistic (8 projects, recurring revenue)
**Revenue:** €95k (6 new + €10k recurring maintenance)  
**COGS:** €8k  
**Gross Profit:** €87k (92% margin)  
**Operating Expenses:** €6k (hiring subcontractor, marketing)  
**EBIT:** €81k  
**Taxes (~45%):** €36.5k  
**Net Income:** €44.5k

**Key assumption:** Revenue growth via referrals + reputation (not aggressive sales spending).

---

## PART 7: RISKS & MITIGATIONS

| Risk | Impact | Likelihood | Mitigation |
|------|--------|-----------|-----------|
| **Scope creep** | Projects overrun, margin collapses | High | Fixed-scope contracts, "change request" process, clear written requirements |
| **Client delay** | Projects extend beyond 8 weeks | Medium | Phase gates, client sign-offs, escalation plan |
| **Low demand** (not enough leads) | Revenue below forecast | Medium | Active outreach, referral program, content marketing |
| **Technology risk** (Supabase downtime, etc.) | Client project fails | Low | Redundancy, SLA monitoring, fallback deployment plan |
| **Burnout** (too many concurrent projects) | Quality suffers | Medium | Limit to 2 concurrent projects max, hire subcontractor if needed |
| **Competition underpricing** | Price pressure | Medium | Differentiate on speed + quality, case studies, testimonials |
| **Regulatory/compliance** (GDPR, Data Acts) | Legal liability | Low | Legal review of contracts, DPA templates, privacy-first by design |

---

## PART 8: SUCCESS METRICS (KPIs)

**Sales:**
- Qualified leads per month (target: 5)
- Conversion rate (target: 15%)
- Average project value (target: €11k)
- Sales cycle (target: 4-8 weeks)

**Delivery:**
- On-time delivery rate (target: 100%)
- Scope adherence (target: 95% no major changes)
- Client satisfaction (NPS target: 8/10)
- Post-launch bug rate (target: <5 critical issues/project)

**Financial:**
- Gross margin (target: 90%+)
- Utilization rate (target: 80% billable time)
- Project profitability (target: 60%+ margin)
- Repeat/referral rate (target: 30%+ of new revenue from referrals)

---

## PART 9: NEXT STEPS (IMMEDIATE ACTIONS)

### Month 1 (July-August)
- [ ] Finalize business name & branding
- [ ] Draft communication plan (content calendar, messaging)
- [ ] Launch website (5 pages)
- [ ] Publish first case study (Treepin)
- [ ] Research & compile 20-30 target municipalities (digitalization officers)

### Month 2 (September)
- [ ] Formalize legal structure (eenmanszaak registration, RSZ)
- [ ] Establish billing/contract templates
- [ ] Begin cold outreach (municipalities)
- [ ] LinkedIn thought leadership (2x/week posts)
- [ ] Secure first paying client (target: Q4 2026)

### Month 3+ (October onward)
- [ ] Deliver first project (case study #2)
- [ ] Referral program formalization
- [ ] Blog/content expansion
- [ ] Explore recurring revenue (maintenance contracts)

---

## APPENDIX: QUESTIONS FOR JONATHAN

1. **Revenue sensitivity:** Would you consider lower prices (€5-8k) for nonprofits/MVPs? Or stick with €8-12k minimum?
2. **Scope management:** How rigid are you on the 6-8 week timeline? What if a client requests extension?
3. **Support model:** Would you offer post-launch support as default (30 days) or upsell?
4. **Portfolio:** Which of Treepin/Tagalong/IoT do you want front-and-center in marketing?
5. **Domain focus:** Go vertical (municipalities only) or horizontal (multi-sector)?
6. **Hiring timeline:** When would you consider bringing in a subcontractor to scale?

---

**Document Version:** 0.1  
**Last Updated:** July 22, 2026  
**Status:** Ready for feedback & iteration
