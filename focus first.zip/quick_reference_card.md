# QUICK REFERENCE CARD: FOCUS FIRST DIGITAL LAB
## Brand Specs, Colors, Typography, Sizing

---

## BRAND IDENTITY

**Business Name:** Focus First Digital Lab  
**Tagline:** "We analyze your problem. Build the solution. Fast."  
**Tagline (alt):** "Problem → Data → Solution. 6-8 weeks."  
**Domains:** focusfirst.studio | focusfirst.be  
**Email:** jonathan@focusfirst.studio (or .be)  
**LinkedIn:** @focusfirstdigitallab  

---

## LOGO SPECS

**Mark:** Three overlapping lines (geometric, line-weight style)  
- Line 1: (60, 200) → (140, 40)
- Line 2: (128, 220) → (128, 20)
- Line 3: (196, 200) → (116, 40)
- Stroke: 2px, round caps/joins
- Canvas: 256px × 256px

**Wordmark:**
```
FOCUS FIRST
Digital Lab
```
- "FOCUS FIRST": Inter Bold 48px, uppercase, +0.5px letter spacing
- "Digital Lab": Inter Regular 20px, title case
- Spacing: 8px between lines

**Exports:**
- SVG: mark-dark.svg, mark-emerald.svg, mark-inverted.svg, wordmark.svg
- PNG: favicon-32.png, favicon-64.png, social-avatar-128.png

---

## COLOR PALETTE

### Neutral Base
| Name | Hex | RGB | Use |
|------|-----|-----|-----|
| White | #FFFFFF | 255, 255, 255 | Background |
| Cream | #F9F8F6 | 249, 248, 246 | Card bg, subtle |
| Light Gray | #F0EEE8 | 240, 238, 232 | Borders, dividers |
| Medium Gray | #A9A8A1 | 169, 168, 161 | Secondary text |
| Dark Gray | #3A3935 | 58, 57, 53 | Body text, logo outline |
| Near Black | #1A1915 | 26, 25, 21 | Headlines |

### Accent Color (Emerald)
| Name | Hex | RGB | Use |
|------|-----|-----|-----|
| Emerald (Primary) | #2DB88F | 45, 184, 143 | Icon, mark filled |
| Emerald (Dark) | #1B6E4F | 27, 110, 79 | Hover state, dark bg |
| Emerald (Light) | #E8F5F1 | 232, 245, 241 | Light bg, hover bg |

**Primary use:** CTA buttons, accent icons, process diagram highlights (max 10% of page)

---

## TYPOGRAPHY

### Font Stacks

**Headlines & Wordmark:**
```css
font-family: 'Inter', sans-serif;
font-weight: 700; /* Bold */
```

**Body & UI:**
```css
font-family: 'Inter', sans-serif;
font-weight: 400; /* Regular */
```

**Code & Technical:**
```css
font-family: 'IBM Plex Mono', monospace;
font-weight: 400; /* Regular */
```

### Type Scale

| Element | Size (Desktop) | Size (Mobile) | Weight | Line Height |
|---------|---|---|---|---|
| H1 | 48px | 36px | Bold (700) | 1.1 |
| H2 | 36px | 28px | Bold (700) | 1.2 |
| H3 | 24px | 20px | Semi-bold (600) | 1.3 |
| H4 | 18px | 16px | Semi-bold (600) | 1.4 |
| Body | 16px | 16px | Regular (400) | 1.6 |
| Small | 14px | 14px | Regular (400) | 1.5 |
| Code | 14px | 13px | Regular (400) | 1.4 |

### Google Fonts Import
```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=IBM+Plex+Mono:wght@400&display=swap');
```

---

## SPACING SYSTEM (8px base)

| Scale | Size | Use |
|-------|------|-----|
| xs | 4px | Micro spacing, tight elements |
| sm | 8px | Button padding, small gaps |
| md | 16px | Section padding, card spacing |
| lg | 24px | Section padding, larger gaps |
| xl | 32px | Page margins, major sections |
| 2xl | 48px | Hero gaps, large features |
| 3xl | 64px | Between major sections |

### Common Spacing Patterns

**Page container:** Max width 1280px, padding 24px (desktop) / 16px (mobile)  
**Section gap:** 64px (desktop), 48px (mobile)  
**Card padding:** 24-32px  
**Line height:** 1.6 for body text

---

## ICON SPECS

**Style:** Geometric, minimal, no gradients/shadows  
**Base size:** 24px  
**Stroke width:** 1.5px (for line icons)  
**Color:** Dark Gray (#3A3935) or Emerald (#2DB88F)  
**Library:** Feather Icons (feathericons.com)

**Custom icons needed:**
- Analyze (magnifying glass)
- Build (database or gear)
- Ship (rocket or checkmark)

---

## BUTTON STYLES

### Primary CTA Button
```
Background: Emerald (#2DB88F)
Text: White (#FFFFFF)
Padding: 12px 24px
Font: Inter Semi-bold (600), 16px
Border radius: 4px
Hover: Background Dark Emerald (#1B6E4F)
```

### Secondary Button
```
Background: Light Gray (#F0EEE8)
Text: Dark Gray (#3A3935)
Padding: 12px 24px
Font: Inter Regular (400), 16px
Border radius: 4px
Hover: Background Cream (#F9F8F6)
```

---

## TAILWIND CONFIG SNIPPET

```js
module.exports = {
  theme: {
    colors: {
      white: '#FFFFFF',
      cream: '#F9F8F6',
      'light-gray': '#F0EEE8',
      'medium-gray': '#A9A8A1',
      'dark-gray': '#3A3935',
      'near-black': '#1A1915',
      accent: {
        DEFAULT: '#2DB88F',
        dark: '#1B6E4F',
        light: '#E8F5F1',
      },
    },
    fontFamily: {
      sans: ['Inter', 'sans-serif'],
      mono: ['IBM Plex Mono', 'monospace'],
    },
    spacing: {
      xs: '4px',
      sm: '8px',
      md: '16px',
      lg: '24px',
      xl: '32px',
      '2xl': '48px',
      '3xl': '64px',
    },
  },
}
```

---

## RESPONSIVE BREAKPOINTS

| Device | Width | Use |
|--------|-------|-----|
| Mobile | <640px | Single column, no hero image |
| Tablet | 640px-1024px | 2 columns, reduced spacing |
| Desktop | >1024px | Full layout, max 1280px |

---

## SEO & META TAGS

### Homepage Meta
```html
<title>Focus First Digital Lab — Problem → Data → Solution</title>
<meta name="description" content="We analyze your problem. Build the solution. Fast. 6-8 weeks.">
<meta name="og:title" content="Focus First Digital Lab">
<meta name="og:description" content="We analyze your problem. Build the solution. Fast.">
<meta name="og:image" content="https://focusfirst.studio/og-image.png">
```

### Case Study Meta (template)
```html
<title>[Project Name] Case Study — Focus First Digital Lab</title>
<meta name="description" content="How we [Problem]. [Solution]. [Outcome].">
<meta name="og:image" content="https://focusfirst.studio/[project]-og.png">
```

---

## CONTENT TONE RULES

### Do Write
✅ "We analyze your problem before we code."  
✅ "6-8 weeks. Fixed price. No surprises."  
✅ "Cost cut from €50-150 to €10-30 per unit."  
✅ "Most solutions fail because they solve the wrong problem."

### Don't Write
❌ "Cutting-edge innovation" | "World-class team" | "Synergistic paradigm shifts"  
❌ Vague claims ("significant", "huge", "revolutionary")  
❌ Jargon without explanation  
❌ Hidden limitations or asterisks

---

## FIGMA FILE SETUP

**Project Name:** Focus First Digital Lab  
**Main file:** focusfirst-branding.fig

**Pages:**
- Mark Design (logo construction, variants)
- Wordmark (typography lockups)
- Lockups (mark + wordmark combinations)
- Color Palette (swatches, reference)
- Typography (specimens, scales)
- Website Components (buttons, cards, sections)
- Export Prep (SVG/PNG exports)

---

## VERCEL/NEXT.JS SETUP

**Build command:** `npm run build`  
**Start command:** `npm run dev`  
**Output directory:** `.next`

**Environment variables (if needed):**
```
NEXT_PUBLIC_SITE_URL=https://focusfirst.studio
NEXT_PUBLIC_GA_ID=G-[YOUR-GA-ID]
```

**Vercel deployment:** Auto-deploy on git push to main

---

## LINKEDIN POSTING SCHEDULE

**Frequency:** 2x per week (Monday + Thursday)  
**Content pillars:**
- Problem-first thinking (30%)
- Speed & methodology (25%)
- Proof (outcomes) (25%)
- Industry insights (20%)

**Time of post:** 9 AM CET (optimal engagement)

---

## COLD OUTREACH TARGETS

**Municipalities:**
- 20-30 emails
- Target: Digitalization officers, IT coordinators
- Pain point: Manual processes, data fragmentation
- Angle: Treepin proof (gemeente Maldegem)

**Construction Firms:**
- 15-20 emails
- Target: Project managers, site managers, owners
- Pain point: Site coordination, safety docs
- Angle: Speed before enterprise ERP

**Startups/Scale-ups:**
- 10-15 emails
- Target: Founders, CTOs
- Pain point: MVP validation before hiring
- Angle: 6-8 weeks vs. 6 months, investor-ready

---

## KEY METRICS TO TRACK

**Website:**
- Page views (especially case studies)
- CTA click-through rate (Calendly link)
- Mobile vs. desktop traffic
- Bounce rate (target: <50%)
- Conversion: visitor → calendar booking

**LinkedIn:**
- Post reach & impressions
- Engagement rate (comments/likes)
- Profile views
- Connection requests

**Sales:**
- Cold emails sent / response rate (target: 10-15%)
- Conversations scheduled / conversion rate (target: 10-20%)
- Proposals sent / close rate (target: 25-50%)
- Average project value (target: €11k+)

---

## FILE NAMING CONVENTION

**Logo files:**
- `focusfirst-mark-dark.svg`
- `focusfirst-mark-emerald.svg`
- `focusfirst-wordmark.svg`
- `focusfirst-lockup-horizontal.svg`

**Web assets:**
- `favicon-32.png`
- `apple-touch-icon-180.png`
- `og-image-1200x630.png`

**Blog posts:**
- `/blog/why-90-percent-fail.mdx`
- `/blog/data-flow-audit.mdx`

---

## QUICK CHECKLIST (Before Launch)

- [ ] Logo finalized (SVG + PNG exports)
- [ ] Figma file organized & clean
- [ ] Website deployed to Vercel
- [ ] Domain pointing to Vercel (DNS)
- [ ] Favicon visible in browser
- [ ] Calendly embed working
- [ ] Analytics tracking
- [ ] Mobile responsive (tested)
- [ ] Lighthouse score >90
- [ ] LinkedIn profile updated
- [ ] Email signature updated
- [ ] Cold outreach emails ready
- [ ] Blog post 1 scheduled
- [ ] 8 LinkedIn posts scheduled

---

**Print this or save as bookmark. Reference constantly during build.**

**Version:** 1.0  
**Last Updated:** July 23, 2026
