# BRAND BRIEF: FOCUS FIRST DIGITAL LAB
## Visual Identity System & Guidelines

**Brand Name:** Focus First Digital Lab  
**Tagline:** We analyze your problem. Build the solution. Fast.  
**Domains:** focusfirst.studio | focusfirst.be  
**Founded:** July 2026  
**Founder:** Jonathan (Solo, Gent Belgium)

---

## PART 1: BRAND IDENTITY

### Core Values

**1. Focus**
- We ask the hard questions first
- We ignore distractions
- We solve the right problem (not the wrong one well)

**2. Speed**
- 6-8 weeks, always
- No endless deliberation
- Discipline over perfection

**3. Clarity**
- No jargon
- Honest about trade-offs
- Say what we mean, mean what we say

**4. Craft**
- We build with intention
- Code quality matters
- Details are deliberate (not accidental)

---

### Brand Personality

**The tone (how we sound):**
- **Smart** (not condescending)
- **Honest** (not salesy)
- **Direct** (not flowery)
- **Accessible** (not academic)
- **Provocative** (question assumptions)

**Visual personality:**
- **Modern** (not trendy)
- **Geometric** (not organic)
- **Minimal** (not sparse)
- **Intentional** (not accidental)
- **Forward-thinking** (not dated)

---

## PART 2: LOGO & WORDMARK

### Logo Direction

**Concept: "Focus" as a geometric system**

The logo represents the methodology: **Problem → Data → Solution**

Three variations of logo complexity:

#### Option A: Geometric Mark (Recommended)
```
A simple circle with a "crosshair" or "target" center point.
This represents:
- Focus (optical metaphor)
- Process (layered circles = iterations)
- Clarity (clean geometry)

Execution:
- Perfect circle (outer)
- Inner circle (2/3 size)
- Center point (sharp crosshair)
- Negative space between rings = "focus"

Colors: Monochrome primary (can apply accent color)
Size: Scales well from 16px to billboard
Recognizable at small sizes? YES
Memorable? YES
Unique? YES (geometric, not photographic)
```

#### Option B: Simplified Line Work
```
Three overlapping lines forming a triangle/prism shape.
This represents:
- Three-step process (analyze → build → ship)
- Forward momentum
- Data flow

Execution:
- Three clean lines
- Geometric, not organic
- Can be drawn with a single stroke

Colors: Monochrome primary
Simplicity? HIGH
Versatility? HIGH
```

#### Option C: Lettermark (Fallback)
```
"FF" monogram (Focus First)
With geometric treatment:
- Two F's interlocking
- Modern, typographic
- Works as standalone mark

Execution:
- Bold sans-serif (Inter Bold or similar)
- Geometric proportions
- Can be placed above wordmark

Use case: Favicon, small app icon, email signature
```

**RECOMMENDATION:** Option A (Circle + Crosshair)
- Most recognizable
- Scalable across all sizes
- Represents methodology
- Memorable

---

### Wordmark

**Primary: "Focus First Digital Lab"**

**Execution:**
- Line 1: "Focus First" (bold, uppercase or title case)
- Line 2: "Digital Lab" (lighter weight, smaller, supporting)

**Typography hierarchy:**
```
FOCUS FIRST
Digital Lab
```

**Alternative stacked (logo above):**
```
   [CIRCLE MARK]
   Focus First
   Digital Lab
```

**Standalone/URL version:**
```
focusfirst
(suffixed by .studio or .be depending on context)
```

---

### Logo Variations

**1. Lockup (mark + wordmark together)**
```
[MARK]  FOCUS FIRST
        Digital Lab
```
**Use:** Website hero, printed business card, large displays

**2. Horizontal (mark left of text)**
```
[MARK] Focus First Digital Lab
```
**Use:** Email signatures, social media headers, documents

**3. Stacked (mark above text)**
```
      [MARK]
   FOCUS FIRST
   Digital Lab
```
**Use:** Favicon, app icons, square formats

**4. Mark only**
```
   [MARK]
```
**Use:** App icon (iOS/Android), favicon, social avatar, merchandise

**5. Wordmark only (no mark)**
```
FOCUS FIRST
Digital Lab
```
**Use:** Minimal footer, text-only headers, constraint spaces

---

## PART 3: COLOR PALETTE

### Primary Colors

**Neutral Base:**
- **White:** `#FFFFFF` (backgrounds, primary)
- **Off-white/Cream:** `#F9F8F6` (subtle backgrounds, cards)
- **Light Gray:** `#F0EEE8` (borders, dividers)
- **Medium Gray:** `#A9A8A1` (secondary text)
- **Dark Gray:** `#3A3935` (body text, primary)
- **Near Black:** `#1A1915` (headlines, highest contrast)

**Accent Color (choose ONE):**

Option 1: **Emerald (Recommended)**
- Primary: `#1B6E4F` (deep, professional)
- Light: `#E8F5F1` (hover, light backgrounds)
- Bright: `#2DB88F` (CTA buttons, emphasis)
- Use: Professional, nature-connected, calming authority

Option 2: **Navy**
- Primary: `#0B3D5C` (classic, corporate-friendly)
- Light: `#E8F0F7` (hover, light backgrounds)
- Bright: `#0D5A8F` (CTA buttons, emphasis)
- Use: Corporate, trust, stability

Option 3: **Charcoal + Accent Teal**
- Neutral: `#2D2D2D` (dark, high contrast)
- Accent: `#00A8A8` (teal, energetic, modern)
- Light: `#E0EEEE` (hover, light backgrounds)
- Use: Forward-thinking, tech-savvy, modern

**RECOMMENDATION: Emerald** (Option 1)
- Differentiates from typical tech blue
- Aligns with "problem-solving", "growth", "nature"
- Accessible (good contrast ratios)
- Works across all mediums

---

### Color Usage Rules

**Headlines & Primary Text:**
- Use Near Black `#1A1915`
- Maintain high contrast for readability

**Body Copy:**
- Use Dark Gray `#3A3935`
- Minimum 16px font size
- Line height: 1.6+

**Interactive Elements (Buttons, Links):**
- Use Accent Color (Emerald `#2DB88F`)
- Hover state: Slightly darker (Emerald `#1B6E4F`)
- Focus state: Add border + outline (accessibility)

**Backgrounds & Cards:**
- Use White `#FFFFFF` or Off-white `#F9F8F6`
- Subtle shadows, not harsh borders

**Dividers & Borders:**
- Use Light Gray `#F0EEE8`
- Minimal visual weight

**Accent Uses:**
- CTA buttons (primary)
- Hover states (secondary)
- Icon fills (supporting)
- Process diagram highlights (methodology visuals)
- Do NOT overuse (max 10% of page)

---

## PART 4: TYPOGRAPHY

### Font Stack

**Headlines (H1-H3):**
- Primary: **Inter** (Google Fonts, free)
- Weight: Bold (700) or Semi-bold (600)
- Case: Uppercase for H1 (max 40px), Title case for H2-H3
- Line height: 1.1-1.2 (tight)
- Letter spacing: +0.5px on uppercase (readability)

**Body Text:**
- Primary: **Inter** (Google Fonts)
- Weight: Regular (400)
- Size: 16px minimum (mobile), 18px (desktop)
- Line height: 1.6
- Letter spacing: 0 (default)

**Technical/Code:**
- Primary: **IBM Plex Mono** (Google Fonts, free)
- Weight: Regular (400)
- Size: 14px (code blocks), 13px (inline code)
- Line height: 1.4 (tight)
- Use: Case studies with tech details, API docs, examples

**Font Import (CSS):**
```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=IBM+Plex+Mono:wght@400&display=swap');

body {
  font-family: 'Inter', sans-serif;
}

h1, h2, h3 {
  font-family: 'Inter', sans-serif;
  font-weight: 700;
}

code, pre {
  font-family: 'IBM Plex Mono', monospace;
}
```

---

### Type Scales

**Headlines:**
```
H1: 48px / 52px (desktop)  | 36px (mobile)  | Bold | Uppercase
H2: 36px / 40px (desktop)  | 28px (mobile)  | Bold | Title case
H3: 24px / 28px (desktop)  | 20px (mobile)  | Semi-bold | Title case
H4: 18px / 20px (desktop)  | 16px (mobile)  | Semi-bold | Sentence case
```

**Body:**
```
Body: 16px / 18px (desktop) | 16px (mobile) | Regular | Sentence case
Small: 14px / 16px (desktop) | 14px (mobile) | Regular | Sentence case
```

---

## PART 5: VISUAL ELEMENTS

### Icons

**Style:**
- Geometric, minimal line-weight or filled
- 24px base size (scales up/down as needed)
- No drop shadows, no gradients
- Consistent stroke width (1.5px for line icons)

**Usage:**
- Process steps (Problem → Data → Solution)
- Feature highlights (Speed, Clarity, Craft)
- Navigation (Contact, Case Studies, etc.)

**Icon Library Recommendation:**
- Use: Feather Icons (open-source, minimal, perfect fit)
- URL: feathericons.com
- Customization: Match your accent color (Emerald)

**Custom Icons for Core Methodology:**
```
PROBLEM/ANALYZE:
Magnifying glass or microscope icon
(representing deep investigation)

DATA:
Database or network diagram icon
(representing data flows)

SOLUTION/BUILD:
Gear or builder/construction icon
(representing creation)
```

---

### Visual Patterns

**Hero Sections:**
- Large typography
- Minimal decoration (maybe accent circle/geometric shape in background)
- High contrast text on white/off-white
- No stock photos
- Optional: Subtle geometric shapes (circles, lines) as background texture

**Process Diagrams:**
- Three-step flow (left to right, or top to bottom)
- Icons + text descriptions
- Accent color for highlights
- Arrows connecting steps (simple, clean)

**Case Studies:**
- Problem statement (bold, headline size)
- Data section (calm, supporting)
- Solution (visual diagram or screenshot)
- Outcome (quantified, if possible)

**Cards & Content Blocks:**
- Off-white background `#F9F8F6`
- Light gray border `#F0EEE8` (if needed, minimal)
- Generous padding (24-32px)
- No drop shadows (use borders or subtle background tint instead)

---

## PART 6: PHOTOGRAPHY & IMAGERY

**DO:**
- Use illustrations (geometric, minimal)
- Use diagrams (process flows, architecture)
- Use screenshots (clean, minimal UI)
- Use icons (Feather Icons or custom)

**DON'T:**
- Stock photos (laptop, code on screen, team meeting)
- Photorealistic images
- Emojis
- Gradients or drop shadows
- Low-contrast text on busy backgrounds

**Recommended Tools for Creating Imagery:**
- Figma (design system, prototypes, exports)
- Excalidraw (diagrams, flowcharts, quick sketches)
- Simple SVG exports (scalable, clean)

---

## PART 7: SPACING & LAYOUT

### Spacing System (8px base)

```
xs:  4px   (micro-spacing)
sm:  8px   (button padding, small gaps)
md:  16px  (section padding, card spacing)
lg:  24px  (section padding, large gaps)
xl:  32px  (page margins, major sections)
2xl: 48px  (hero section gaps, large features)
3xl: 64px  (between major sections)
```

### Padding & Margins

**Page container:**
- Max width: 1280px (desktop)
- Padding: 24px (tablet), 16px (mobile)

**Section spacing:**
- Between major sections: 64px (desktop), 48px (mobile)
- Between related content: 24px

**Card padding:**
- Interior padding: 24-32px

**Text spacing:**
- Paragraph margin-bottom: 16px
- Heading margin-bottom: 16-24px

---

## PART 8: BRAND GUIDELINES (QUICK REFERENCE)

### Do's

✅ **Logo:**
- Clear space: min 8px around mark
- Never distort or rotate
- Use clean vector (not rasterized)
- Maintain aspect ratio

✅ **Color:**
- Use Emerald accent sparingly (10% max of page)
- Maintain high contrast for text (WCAG AA minimum)
- Use full-width color sections only for CTAs/features

✅ **Typography:**
- Use Inter for all body copy and headlines
- Maintain 16px minimum for body text
- Use uppercase for H1 only

✅ **Imagery:**
- Keep illustrations minimal and geometric
- Use diagrams for process explanation
- Keep screenshots clean and focused

✅ **Tone:**
- Be clear, direct, honest
- No buzzwords or corporate speak
- Use specific numbers (not "significant" or "huge")

### Don'ts

❌ **Logo:**
- Never add effects (drop shadows, glows, gradients)
- Never reverse colors on non-white backgrounds (mark only)
- Never recreate from scratch (use source file)
- Never combine with other logos

❌ **Color:**
- Never use more than one accent color
- Never use bright neon or desaturated shades
- Never apply color to body text (use only for emphasis)
- Never use color alone for information (always pair with text/icon)

❌ **Typography:**
- Never use condensed or expanded letter spacing on body copy
- Never use more than 2 typefaces (Inter + IBM Plex Mono)
- Never use drop shadows on text
- Never go below 16px for body text (desktop)

❌ **Imagery:**
- Never use blurry or low-quality images
- Never mix photographic and illustrated styles
- Never use generic stock photos
- Never rely on imagery alone (always pair with text)

❌ **Tone:**
- Never use jargon without explanation
- Never oversell or hype
- Never claim things you haven't proven
- Never hide limitations or trade-offs

---

## PART 9: IMPLEMENTATION CHECKLIST

### Phase 1: Foundation (Weeks 1-2)
- [ ] Finalize logo (vector format: .svg, .ai)
- [ ] Export logo variations (mark, wordmark, lockup, stacked)
- [ ] Finalize color palette (hex codes confirmed)
- [ ] Set up Figma design system
- [ ] Create typography system (styles, scales)
- [ ] Create icon library (20-30 core icons)

### Phase 2: Brand Assets (Weeks 2-3)
- [ ] Business cards (design + print order)
- [ ] Email signature template
- [ ] LinkedIn cover image + profile picture
- [ ] Social media templates (post, story)
- [ ] Favicon + app icon
- [ ] PDF letterhead template

### Phase 3: Website Implementation (Weeks 3-4)
- [ ] Website design system setup (Figma)
- [ ] Homepage mockup (using brand guidelines)
- [ ] Case study template
- [ ] Process page template
- [ ] Pricing page template
- [ ] About/Contact page template

### Phase 4: Documentation (Week 4)
- [ ] Brand guidelines PDF (shareable)
- [ ] Logo usage guide
- [ ] Color palette reference
- [ ] Typography specimens
- [ ] Icon library documentation

---

## PART 10: VISUAL EXAMPLES

### Example: Hero Section
```
[Clean white background]

FOCUS FIRST
Digital Lab

We analyze your problem.
Build the solution. Fast.

[Small geometric shapes in background - subtle circles/lines in light gray]

[Green CTA button: "Let's talk"]
```

### Example: Process Section
```
[Three columns, equal spacing]

[Icon: Magnifying glass]
ANALYZE
What's the real problem?
(Week 1-2)

[Icon: Database]
BUILD
What does the data tell us?
(Week 3-5)

[Icon: Rocket/checkmark]
SHIP
Deploy and learn.
(Week 6-8)
```

### Example: Case Study Card
```
[Off-white card background]

PROBLEM:
"Tree inspections were slow, dangerous, expensive"

DATA:
"Location, health status, maintenance history"

SOLUTION:
"GIS app + mobile + prioritization"

OUTCOME:
"Cost: €10-30 per inspection (was €50-150)"

[Subtle green accent bar on left or bottom]
```

---

## PART 11: BRAND VOICE REFERENCE

### Tone Examples

**DO WRITE:**
- "We analyze your problem before we code."
- "Most solutions fail because they solve the wrong problem."
- "6-8 weeks. Fixed price. No surprises."
- "What's the real constraint? That's where we start."

**DON'T WRITE:**
- "Cutting-edge digital transformation solutions"
- "We leverage synergistic paradigm shifts"
- "Innovative approaches to complex challenges"
- "Our world-class team delivers excellence"

---

## PART 12: DESIGN SYSTEM (TAILWIND CSS EQUIVALENT)

If building website with Tailwind or similar:

```
Colors:
  white: #FFFFFF
  cream: #F9F8F6
  light-gray: #F0EEE8
  medium-gray: #A9A8A1
  dark-gray: #3A3935
  near-black: #1A1915
  accent (emerald): #2DB88F
  accent-dark: #1B6E4F
  accent-light: #E8F5F1

Typography:
  font-sans: 'Inter', sans-serif
  font-mono: 'IBM Plex Mono', monospace
  
Spacing:
  xs: 4px, sm: 8px, md: 16px, lg: 24px, xl: 32px, 2xl: 48px, 3xl: 64px

Border radius:
  sm: 2px, md: 4px, lg: 8px
  (Prefer sharp, minimal corners)

Shadows:
  NONE (use borders and backgrounds instead)
```

---

## SUMMARY

**Focus First Digital Lab** is:
- **Modern** (geometric, minimal, intentional)
- **Accessible** (high contrast, readable, clear)
- **Versatile** (works at all sizes, all mediums)
- **Memorable** (distinctive mark, clear wordmark)
- **Scalable** (systematic, documented, extensible)

**The visual identity supports the methodology:**
- Focus (circle mark represents precision)
- Speed (clean, minimal aesthetic suggests efficiency)
- Clarity (high contrast, readable, unambiguous)
- Craft (intentional details, quality execution)

---

**Document Version:** 1.0  
**Last Updated:** July 23, 2026  
**Status:** Ready for design implementation
