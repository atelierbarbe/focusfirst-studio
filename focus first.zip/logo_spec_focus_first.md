# LOGO DESIGN SPECIFICATION: FOCUS FIRST DIGITAL LAB
## Line Work Option (Three Overlapping Lines)

**Logo Concept:** Three clean lines forming a geometric shape representing the methodology: Problem → Data → Solution

---

## PART 1: MARK DESIGN (Logo/Icon)

### Core Concept: Three Overlapping Lines

**Metaphor:**
- Line 1 = Problem (Analysis phase)
- Line 2 = Data (Understanding phase)
- Line 3 = Solution (Build phase)
- Intersection = Focus point

**Visual Result:**
Three lines overlap to create a triangular/prism-like form, suggesting:
- Forward momentum (all lines point slightly forward/up)
- Connection (lines intersect, not isolated)
- Process (sequential, layered)

---

### CONSTRUCTION SPECS (Figma)

**Canvas Size:** 256px × 256px (start large, scale down)

**Line Specifications:**
- Stroke width: 2px (at 256px size; scale proportionally)
- Stroke cap: Round (softer look)
- Stroke join: Round (smooth intersections)
- Fill: None (outline only)
- Color: Dark Gray `#3A3935` (primary), or Emerald `#2DB88F` (accent variant)

**Line 1 (Problem - Left line):**
- Angle: 30° from vertical (tilts right)
- Start point: (60, 200)
- End point: (140, 40)
- Length: ~170px
- Purpose: Leftmost line, sets foundation

**Line 2 (Data - Center line):**
- Angle: Vertical (0°)
- Start point: (128, 220)
- End point: (128, 20)
- Length: ~200px
- Purpose: Tallest line, anchors center

**Line 3 (Solution - Right line):**
- Angle: -30° from vertical (tilts left)
- Start point: (196, 200)
- End point: (116, 40)
- Length: ~170px
- Purpose: Rightmost line, completes triangle

**Result:** Three lines converge at top to a triangular point, diverge at bottom

---

### PROPORTIONS (Scale-independent)

```
       ▲ (converge point at top)
      /|\
     / | \
    /  |  \
   /   |   \
  ╱    │    ╲ (lines at widest, bottom area)
```

**Key measurements:**
- Converge distance (top): ~80px (at 256px canvas)
- Diverge distance (bottom): ~140px (at 256px canvas)
- Height: ~200px (at 256px canvas)
- Total canvas usage: ~90% width, ~85% height

---

### VARIATIONS

**Variation A: Outline Only (Primary)**
- Stroke: 2px
- Fill: None
- Color: Dark Gray `#3A3935`
- Use: Primary logo, all applications

**Variation B: Monochrome Filled (Accent)**
- Stroke: None
- Fill: Emerald `#2DB88F`
- Color: Solid
- Use: App icon, button icons, supporting graphics

**Variation C: One-color Reversed (Inverse)**
- Stroke: 2px
- Color: White `#FFFFFF`
- Background: Dark Gray `#3A3935`
- Use: Dark backgrounds, inverse contexts

---

## PART 2: WORDMARK

### Primary Wordmark: "FOCUS FIRST" + "Digital Lab"

**Layout:**
```
FOCUS FIRST
Digital Lab
```

**Typography:**
- Line 1 "FOCUS FIRST": Inter Bold (700), 48px (desktop), uppercase
- Line 2 "Digital Lab": Inter Regular (400), 20px (desktop), title case

**Alignment:** Left-aligned (lines stack vertically)

**Letter spacing:** +0.5px on "FOCUS FIRST" (uppercase needs breathing room)

**Color:** 
- "FOCUS FIRST": Dark Gray `#3A3935`
- "Digital Lab": Medium Gray `#A9A8A1` (lighter, supporting)

**Spacing between lines:** 8px (md spacing unit)

---

### Alternative Wordmark (Compact)

For smaller spaces (email signature, social media handle):

```
focusfirst
```

**Typography:** Inter Bold (700), lowercase, 24px

**Use:** When paired with mark, or in constrained spaces

---

## PART 3: LOGO LOCKUPS

### Lockup 1: Mark + Wordmark (Horizontal)

```
[MARK]  FOCUS FIRST
        Digital Lab
```

**Layout:**
- Mark: 80px square, left-aligned
- Wordmark: Left of mark, 16px gap
- Vertical center-aligned

**Use:** 
- Website hero
- Large digital displays
- Print (business card landscape)

**Min width:** 240px

---

### Lockup 2: Mark + Wordmark (Stacked)

```
      [MARK]
      FOCUS FIRST
      Digital Lab
```

**Layout:**
- Mark: Centered, top
- Wordmark: Centered below mark, 16px gap
- All elements center-aligned

**Use:**
- App icons (iOS/Android)
- Square social media profiles
- Favicon
- Favicon + text (small size)

**Min size:** 120px square

---

### Lockup 3: Mark Only

```
[MARK]
```

**Layout:** Standalone mark

**Use:**
- Favicon
- App icon (iOS/Android)
- Social media avatar
- Merchandise (t-shirt label)
- Document watermark (very light)

**Min size:** 32px (favicon), 192px+ (app icon)

---

### Lockup 4: Wordmark Only

```
FOCUS FIRST
Digital Lab
```

**Layout:** No mark

**Use:**
- Text-only footer
- Email signature
- Constrained spaces
- Footer branding

---

## PART 4: SIZE & SCALING

### Master Size (Canvas)
- **256px × 256px** (working size in Figma)
- All measurements scale proportionally below

### Scalable Sizes

| Use Case | Size | Notes |
|----------|------|-------|
| Favicon | 32px | Pixel-perfect, sharp lines |
| Social avatar | 128px | Clear, legible |
| App icon | 192px, 512px | iOS: 192px; Android: 512px |
| Email signature | 64px | Alongside text |
| Website header | 80px | With wordmark |
| Large display | 200px+ | Can go bigger |
| Smallest readable | 24px | Must remain legible |

**Scaling Rule:** Stroke width adjusts proportionally:
- At 256px: stroke 2px
- At 128px: stroke 1px
- At 64px: stroke 1px (don't go thinner)
- At 32px: stroke 1px (limit of readability)

---

## PART 5: FIGMA IMPLEMENTATION GUIDE

### Step 1: Create Canvas
1. New Figma file
2. Create artboard: 256px × 256px
3. Name: "Focus First Mark v1"

### Step 2: Draw Lines
1. Select "Pen" tool (P)
2. Draw 3 lines:
   - Line 1: (60, 200) → (140, 40)
   - Line 2: (128, 220) → (128, 20)
   - Line 3: (196, 200) → (116, 40)
3. Convert to paths (Cmd+Enter)

### Step 3: Styling
1. Select all 3 lines (Cmd+A)
2. Stroke: 2px
3. Stroke color: Dark Gray `#3A3935`
4. Stroke cap: Round
5. Stroke join: Round
6. Fill: None
7. Group (Cmd+G) → Name: "Mark"

### Step 4: Export Variants
1. Create frame 256×256 with mark
2. Duplicate frame 4 times
3. Variant 1: Outline (2px, dark gray) → Export as "mark-dark.svg"
4. Variant 2: Filled (emerald) → Export as "mark-emerald.svg"
5. Variant 3: Inverted (white on dark) → Export as "mark-inverted.svg"
6. Variant 4: Single color (emerald) → Export as "mark-emerald-solid.svg"

### Step 5: Wordmark
1. Add text layer: "FOCUS FIRST"
2. Font: Inter Bold (700)
3. Size: 48px
4. Letter spacing: +0.5px
5. Color: Dark Gray `#3A3935`
6. Add text layer: "Digital Lab"
7. Font: Inter Regular (400)
8. Size: 20px
9. Color: Medium Gray `#A9A8A1`
10. Group (Cmd+G) → Name: "Wordmark"

### Step 6: Lockups
1. Create 4 frames (256×256 each):
   - Lockup Horizontal
   - Lockup Stacked
   - Mark Only
   - Wordmark Only
2. Arrange elements per specs
3. Export each as SVG

### Step 7: Export Settings
- Format: SVG
- Optimization: Enabled
- Include "code" metadata: No
- Precision: 2 decimals
- Name format: "focusfirst-[variant].svg"

---

## PART 6: COLOR SPECIFICATIONS

### Logo Colors

**Primary (Outline):**
- Color: Dark Gray
- Hex: `#3A3935`
- RGB: 58, 57, 53
- CMYK: 0%, 2%, 8%, 77%
- Pantone: 19-1514 (close match)

**Accent (Filled):**
- Color: Emerald
- Hex: `#2DB88F`
- RGB: 45, 184, 143
- CMYK: 76%, 0%, 22%, 28%
- Pantone: 16-5723 (close match)

**Inverse (White):**
- Color: White
- Hex: `#FFFFFF`
- RGB: 255, 255, 255

---

## PART 7: USAGE RULES

### Do's

✅ **Clear Space:** 
- Minimum 8px around mark (at any size)
- No elements inside this zone

✅ **Colors:**
- Use Dark Gray `#3A3935` on white/light backgrounds
- Use Emerald `#2DB88F` on white/light backgrounds (accent)
- Use White `#FFFFFF` on dark backgrounds only

✅ **Sizing:**
- Scale proportionally (maintain aspect ratio)
- Never distort or stretch
- Minimum 24px for readability

✅ **Pairing:**
- Logo + wordmark = full identity
- Mark only = icon usage
- Wordmark only = text-constrained spaces

### Don'ts

❌ **Avoid:**
- Rotating the mark
- Applying drop shadows or glows
- Changing stroke width unevenly
- Reversing colors except on dark backgrounds
- Using in conjunction with other logos
- Rasterizing (keep as vector SVG)
- Changing line angles or proportions
- Adding effects (gradients, patterns, textures)

---

## PART 8: FILE STRUCTURE (Figma)

```
Focus First Digital Lab Branding
├─ Pages
│  ├─ Mark Design
│  │  ├─ 256px Canvas (Master)
│  │  ├─ Line Work (Construction)
│  │  └─ Variants (Dark, Emerald, Inverted, Solid)
│  ├─ Wordmark
│  │  ├─ "FOCUS FIRST Digital Lab"
│  │  └─ "focusfirst" (Compact)
│  ├─ Lockups
│  │  ├─ Horizontal (mark + wordmark)
│  │  ├─ Stacked (mark / wordmark)
│  │  ├─ Mark Only
│  │  └─ Wordmark Only
│  ├─ Color Palette
│  │  ├─ Neutrals (white, grays)
│  │  ├─ Accent (Emerald)
│  │  └─ Reference Grid
│  ├─ Typography
│  │  ├─ Inter (Headlines, Body)
│  │  └─ IBM Plex Mono (Code)
│  └─ Export Prep
│     ├─ SVG Exports (Mark, Wordmark, Lockups)
│     ├─ PNG Exports (Favicon, Social)
│     └─ Web Assets (Inline SVG, Icon fonts)
```

---

## PART 9: EXPORT CHECKLIST

Once logo is finalized, export these files:

### SVG Exports (Vector - Preferred)
- [ ] mark-dark.svg (dark gray outline)
- [ ] mark-emerald.svg (filled emerald)
- [ ] mark-inverted.svg (white on dark)
- [ ] wordmark.svg (full lockup)
- [ ] wordmark-compact.svg ("focusfirst" only)

### PNG Exports (Raster - Fallback)
- [ ] mark-dark-128.png
- [ ] mark-dark-256.png
- [ ] wordmark-horizontal-256.png
- [ ] favicon-32.png
- [ ] favicon-64.png

### Web Assets (Inline)
- [ ] SVG sprites (mark + wordmark in one file)
- [ ] Favicon (32px .ico)
- [ ] Apple touch icon (180px .png)
- [ ] Android chrome icon (192px, 512px .png)

---

## PART 10: QUICK REFERENCE

**Mark Dimensions (256px base):**
- Line width: 2px
- Total width: ~140px (at 256px canvas)
- Total height: ~200px (at 256px canvas)
- Converge point: Top center
- Diverge width: ~140px (bottom)

**Wordmark Dimensions:**
- "FOCUS FIRST": 48px bold, +0.5px letter spacing
- "Digital Lab": 20px regular, normal spacing
- Vertical gap: 8px
- Total width: ~200px (variable by font)

**Colors:**
- Outline: `#3A3935` (Dark Gray)
- Accent: `#2DB88F` (Emerald)
- Inverse: `#FFFFFF` (White)

**Fonts:**
- Headlines: Inter Bold (700)
- Body: Inter Regular (400)
- Code: IBM Plex Mono (400)

---

**Document Version:** 1.0  
**Last Updated:** July 23, 2026  
**Status:** Ready for Figma implementation
